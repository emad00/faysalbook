<div class="right-bar">
<div class="itemss">
<h3><b>right</b></h3>


<form class="form-inline my-2 my-lg-0">
    <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-dark my-2 my-sm-0" type="submit">Search</button>
</form>

</div>
</div>
