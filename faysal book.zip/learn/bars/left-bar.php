
<div class="itemss">
    <div class="left-bar">
        <h3><b>Account</b></h3>
        <div class="account">
            <p id="account"><b>Name:</b>   <?php ?> <sub><a href="#">edit</a></sub></p>
            <p id="account"><b>Email:</b>   <?php  ?> <sub><a href="#">edit</a></sub></p>
            <p id="account"><b>Password:</b>    <?php  ?> <sub><a href="#">edit</a></sub></p>
            <p id="account"><b>Number:</b>   <?php  ?> <sub><a href="#">edit</a></sub></p>
            <p id="account"><b>Birth Date:</b>    <?php  ?> <sub><a href="#">edit</a></sub></p>
            <p id="account"><b>Gender:</b>    <?php ?> <sub><a href="#">edit</a></sub></p>
        </div>
    </div>
</div>