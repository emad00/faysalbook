<?php
   
    // Database connection
    include('data/cd.php');

?>