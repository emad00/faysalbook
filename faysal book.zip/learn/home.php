<!DOCTYPE html>
<html>

<head>
    <title>Fasal Book 😂</title>
    <script src="http://code.jquery.com/jquery-3.5.1.min.js"
        integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/main.css">

</head>

<link href="icons/download.jpg" rel="icon">

<body id="body">
    <?php include "componets/navbar.php"; ?>
    <div class="bars">
            <?php include "bars/left-bar.php";?>
            <?php include "bars/right-bar.php";?>
        <?php   include "bars/center-bar.php";?>
    </div>
</body>



</html>