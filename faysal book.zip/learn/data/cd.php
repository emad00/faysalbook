<?php
// Enable us to use Headers
ob_start();

// Set sessions
if(!isset($_SESSION)) {
        session_start();
}
$dtb = mysqli_connect("localhost", "root", "","dtb");
if(!$dtb){
    echo '--> error data';
}
?>