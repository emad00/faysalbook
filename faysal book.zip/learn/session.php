<?php
   include('data/cd.php');
   session_start();
   

?>