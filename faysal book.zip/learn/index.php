<?php
   include("data/cd.php");

   
   if($_SERVER["REQUEST_METHOD"] == "POST") {      
      $myemail = mysqli_real_escape_string($dtb,$_POST['email']);
      $mypassword = mysqli_real_escape_string($dtb,$_POST['password']); 
      

   }
?>
<html>

<head>
   <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
   <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
   <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   <link href="css/page.css" rel="stylesheet">
   <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>

   <form class="cont" action="" method="post">
      <div class="all">
         <label id="label" for="Email">email</label>
         <input placeholder="Email" type="text" name="email" class="input" />

         <label id="label" for="password">Password</label>
         <input placeholder="Password" type="password" name="password" class="input" />

         <input class="submit" type="submit" value=" Submit " />
         <br>
         <a href="singup.php">Sing Up</a>
      </div>

   </form>

</body>

</html>